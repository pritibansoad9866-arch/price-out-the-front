# Pricing Out the Front

**Follow the Money · IIM Bangalore CSITM × PayU · "The Bakery That Takes Bets"**
Team Paisa Gaadi Mehenga Ghar: Anirudh Rajesh Negi, Garima Narnaware, Prasad Deore, Paras Bansod

A working prototype of a system that keeps merchant fronts **off** a payment gateway.
The problem is businesses not following their registered business in the lure of illegal
profit, which leads to litigation problems for PayU mainly, but also for honest merchants,
payers and the government. Rather than CATCH, the system makes that illegal profit
economically non-exploitable: after adjusting for risk, a front's cost per rupee through
PayU rises above its next-best channel, so it leaves. Identifying fronts comes second.

It's a repeated game. **Game theory is the architecture, statistics are the mechanics,
technology is the enabler.** It's one general system: each business type plugs in as a
node with its own spec. Kirana is the worked example, and jewellery, restaurant and sports
bar nodes are included too.

## Quick start

```bash
pip install -e ".[app,dev]"

potf run                 # simulate 1,200 merchants for 120 days, run the pipeline, score it
potf rollout             # shadow -> light -> full, side by side
potf game                # the repeated game, round by round
potf economics           # front cost per Rs: status quo vs our system
potf ladder              # the graded ladder and its error budgets

streamlit run app/streamlit_app.py   # dashboard
pytest -q                            # 22 tests
```

## What a default run shows (simulated, seed 7)

1,200 merchants across four nodes, 30 of them fronts (8 run by one syndicate as a fleet).
About 30% of the honest merchants grow or add an adjacent line during the run.

| | Result |
|---|---|
| Fronts delayed or worse | 83%, median 7 days after the front starts |
| Fronts exited (after human review) | 60%, median 11.5 days |
| Syndicate members linked into one fleet | 8 of 8 |
| Honest merchants delayed | 3 of 1,170 (836 per 1M merchant-months; budget 1,000) |
| Honest merchants checked, held or exited | 0 (budgets 200 / 50 / 5 per 1M) |
| Honest merchants with growth or a new side line (338) | 3 delayed (all growth), none checked, held or exited |

Of the fronts not exited, most still sit on a costly rung (delay, check or hold), and those
are fronts that started late in the window, low-volume fronts or one a reviewer cleared.
The ones untouched are mostly mule fronts that were fronts from day one, whose onboarding
level looks like an unusual but plausible shop. Inside the envelope, a front like that earns
little more than the shop itself would. That is the point of the design: the envelope plus
the ladder make small fronts uneconomic and large ones short-lived.

## How it works

**Players.** PayU is the leader and commits one policy for everyone. A legitimate business
does what it declared, and auxiliary or adjacent lines are fine. A front has real documents,
but its money comes from an undeclared trade (betting, mule pass-through).

**Three levers.**
1. **Volume envelope.** Each business type and scale gets a monthly volume. Inside it, a front only earns what that business would. Past it, the extra volume settles slower and stands out.
2. **Verified programme (the carrot).** It's opt in, and the benefits are told upfront: faster settlement and rebates that vest slowly. It's cheap for a real shop and useless to a front. Scrutiny never fully drops, because incentives that eventually reduce scrutiny can encourage behaviour that is ideal upfront and then exploitative later on.
3. **Graded ladder (the stick).** The rungs are watch, prompt, delay, check, hold and exit. Holds apply only to the suspect amount, and a human reviews before anything heavy. Termination differs by type: betting and mule fronts exit with a report, while an undeclared adjacent line is re-categorised.

**Five questions, in order.**

| # | Question | Method | Module |
|---|---|---|---|
| 1 | Anything different? | F-test-esque first flag against peer groups (geographic, industrial, scale) | `stats/flag.py`, `stats/peers.py` |
| 2 | What moved? | kernel MMD per channel (amount, timing, payers) | `stats/mmd.py` |
| 3 | Which explanation? | Bayes factors: growth, decline, adjacent line vs betting, mule | `stats/explain.py` |
| 4 | Is it a fleet? | payer-overlap graph; fleet raises the prior, λ(N) = λ₀(1 + N/N₀); members' evidence corroborates | `stats/fleet.py` |
| 5 | Which rung? | running e-value × inclusion rule ≥ 1/α (Ville), cost ratio, human for heavy rungs | `stats/evalue.py`, `policy/ladder.py` |

**Error budgets set the thresholds.** The budgets are wrongful escalations per 1M merchants a
month: 1,000 for delay, 200 for check, 50 for hold and 5 for exit. Each rung's α is its
budget divided by 1M. For an honest merchant the evidence is a test martingale, so the chance
it *ever* reaches 1/α is at most α. Benign changes are projected out before testing, so growth
or a new side line of any shape adds no evidence. The inclusion rule (declining the programme)
multiplies the evidence by a likelihood ratio whose mean over honest merchants is exactly 1.
That gives it a higher impact, but it's never a conviction on its own.

**Rollout.** It runs in shadow mode first (log only), then the light rungs inside strict error
budgets, then the heavy rungs only with a human. Shadow mode also calibrates the noise safety
margin, so realised false escalations stay inside budget.

**The repeated game** (`potf game`):

| Round | PayU moves | Syndicate responds | Cheapest cost per Rs |
|---|---|---|---|
| 0 | Status quo: KYC once, score each payment | A few big fronts | 0.95% |
| 1 | Cap volume with an envelope, start the ladder | A fleet of small fronts inside the envelope | 1.44% |
| 2 | Link fleets through shared payers | Probe the thresholds, sit just under them | 1.97% |
| 3 | Rotate thresholds at random | Join the verified programme, behave, then exploit | 2.50% |
| 4 | Vest the rewards; scrutiny never fully drops | **Leave PayU** (cheapest left: 3.36% > 3% outside option) | |

## Real data

Real data is wired in but not bundled. The loaders map public datasets onto the same shapes:

- dunnhumby: real stores
- Bustabit: real bets, injected into real stores as semi-real fronts
- IPL: the real match calendar
- Recruit and Favorita: real holiday uplift
- Elliptic: a real labelled illicit graph

See [`data/README.md`](data/README.md) for downloads and commands. A sample run:

```bash
potf real --dunnhumby data/raw/transaction_data.csv --bustabit data/raw/bustabit.csv --ipl data/raw/matches.csv
```

## Repository

```
src/potf/        the system (see docs/architecture.md for the code map)
app/             Streamlit dashboard
tests/           validity, detection, policy, loaders, CLI
data/README.md   real datasets and how to run on them
docs/            architecture, why the budgets hold, limits
```

## Limits

- The default run uses simulated data. The illicit signatures come from node specs and should be learnt from labelled cases.
- The noise model is Gaussian on daily aggregates. Very low-count merchants need a count model.
- The economics are calibrated, not measured. Every number in `config.py` is illustrative.
- Fleet linking uses payer overlap only. Device, bank-account and location links would make it stronger.
